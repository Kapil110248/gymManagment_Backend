// controllers/branch.controller.js
import prisma from "../services/prismaClient.js";
import bcrypt from "bcrypt";

const SALT_ROUNDS = 10; // adjust if needed

// helper to remove sensitive fields before sending response
const removeSensitive = (obj) => {
  if (!obj) return obj;
  const clone = { ...obj };
  if (clone.password) delete clone.password;
  return clone;
};

// Create new branch
export const createBranch = async (req, res) => {
  try {
    const {
      name,
      code,
      address,
      manager,
      phone,
      email,
      username,
      password,
      status,
      hours,
    } = req.body;

    // Basic validation
    if (!name || !code || !username || !password) {
      return res.status(400).json({
        success: false,
        message: "name, code, username and password are required",
      });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

    // Safe hours parsing: handle string or object
    let parsedHours = {};
    if (hours) {
      if (typeof hours === "string") {
        try {
          parsedHours = JSON.parse(hours);
        } catch (err) {
          return res.status(400).json({
            success: false,
            message: "Invalid hours JSON string",
            error: err.message,
          });
        }
      } else if (typeof hours === "object") {
        parsedHours = hours;
      }
    }

    // Handle avatar image uploaded via multer + Cloudinary
    let avatarUrl = "";
    if (req.file && req.file.path) {
      avatarUrl = req.file.path;
    }

    // Create branch in DB
    const branch = await prisma.branch.create({
      data: {
        name,
        code,
        address,
        manager,
        phone,
        email,
        username,
        password: hashedPassword,
        status: status || "Inactive",
        hours: parsedHours,
        avatar: avatarUrl,
      },
    });

    // Return response without sensitive info
    res.status(201).json({ success: true, branch: removeSensitive(branch) });

  } catch (error) {
    console.error("Error creating branch:", error);

    // Prisma unique constraint friendly message
    if (error.code === "P2002" && error.meta?.target) {
      const field = Array.isArray(error.meta.target)
        ? error.meta.target.join(", ")
        : error.meta.target;
      return res.status(409).json({
        success: false,
        message: `Unique constraint failed on the field(s): ${field}`,
        error: error.message,
      });
    }

    // General server error
    res.status(500).json({
      success: false,
      message: "Failed to create branch",
      error: error.message,
    });
  }
};

// Get all branches
export const getAllBranches = async (req, res) => {
  try {
    const branches = await prisma.branch.findMany({
      orderBy: { createdAt: "desc" },
    });
    const safe = branches.map(removeSensitive);
    res.status(200).json({ success: true, branches: safe });
  } catch (error) {
    console.error("Error fetching branches:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch branches",
      error: error.message,
    });
  }
};

// Get branch by id
export const getBranchById = async (req, res) => {
  try {
    const { id } = req.params;
    const branch = await prisma.branch.findUnique({
      where: { id: Number(id) },
    });
    if (!branch) return res.status(404).json({ success: false, message: "Branch not found" });
    res.status(200).json({ success: true, branch: removeSensitive(branch) });
  } catch (error) {
    console.error("Error fetching branch:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch branch",
      error: error.message,
    });
  }
};

// Update branch
export const updateBranch = async (req, res) => {
  try {
    const { id } = req.params;
    const data = { ...req.body };

    // If password provided, hash it before update
    if (data.password) {
      data.password = await bcrypt.hash(data.password, SALT_ROUNDS);
    } else {
      delete data.password;
    }

    // Handle hours if provided as JSON string
    if (data.hours && typeof data.hours === "string") {
      try {
        data.hours = JSON.parse(data.hours);
      } catch (e) {
        // ignore parse error; assume client sent valid JSON
      }
    }

    // Handle avatar image if uploaded
    if (req.file && req.file.path) {
      data.avatar = req.file.path;
    }

    const branch = await prisma.branch.update({
      where: { id: Number(id) },
      data,
    });

    res.status(200).json({ success: true, branch: removeSensitive(branch) });
  } catch (error) {
    console.error("Error updating branch:", error);

    if (error.code === "P2002" && error.meta?.target) {
      const field = Array.isArray(error.meta.target) ? error.meta.target.join(", ") : error.meta.target;
      return res.status(409).json({
        success: false,
        message: `Unique constraint failed on the field(s): ${field}`,
        error: error.message,
      });
    }

    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Branch not found" });
    }

    res.status(500).json({
      success: false,
      message: "Failed to update branch",
      error: error.message,
    });
  }
};

// Delete branch
export const deleteBranch = async (req, res) => {
  try {
    const { id } = req.params;

    await prisma.branch.delete({
      where: { id: Number(id) },
    });

    res.status(200).json({ success: true, message: "Branch deleted successfully" });
  } catch (error) {
    console.error("Error deleting branch:", error);
    if (error.code === "P2025") {
      return res.status(404).json({ success: false, message: "Branch not found" });
    }
    res.status(500).json({
      success: false,
      message: "Failed to delete branch",
      error: error.message,
    });
  }
};
